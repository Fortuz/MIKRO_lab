function g = sigmoid(z)
%SIGMOID Compute sigmoid function

end