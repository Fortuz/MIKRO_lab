function [C, grad] = costFunction(w, X, Y)
%COSTFUNCTION Compute cost and gradient for logistic regression
% Initialize some useful values

end
