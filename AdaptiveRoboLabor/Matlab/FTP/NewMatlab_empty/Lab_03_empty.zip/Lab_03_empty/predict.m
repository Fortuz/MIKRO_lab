function p = predict(w, X)
%PREDICT Predict whether the label is 0 or 1 using learned logistic 

end