function [w] = trainLinearReg(X, y, lambda)
%TRAINLINEARREG Trains linear regression given a dataset (X, y) and a
%regularization parameter lambda

% Initialize weights
init_w = zeros(size(X, 2), 1); 



end
