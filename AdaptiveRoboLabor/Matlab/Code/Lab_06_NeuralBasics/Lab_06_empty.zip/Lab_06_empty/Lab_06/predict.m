function p = predict(w1, w2, X)
%PREDICT Predict the label of an input given a trained neural network
% Useful values
m = size(X, 1);
num_labels = size(w2, 1);



end
