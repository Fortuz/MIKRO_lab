function C = computeCostMulti(X, Y, w)
%COMPUTECOSTMULTI Compute cost for linear regression with multiple variables

% Initialize some useful values

end