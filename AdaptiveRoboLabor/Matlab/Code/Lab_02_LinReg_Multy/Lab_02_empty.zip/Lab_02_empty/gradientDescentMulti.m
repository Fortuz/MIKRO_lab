function [w, C_history] = gradientDescentMulti(X, Y, w, lr, epochs)
%GRADIENTDESCENTMULTI Performs gradient descent to learn w
% Initialize some useful values


end
