function out = mapFeature(X1, X2)
% MAPFEATURE Feature mapping function to polynomial features



end