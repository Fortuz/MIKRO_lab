function [C, grad] = costFunctionReg(w, X, Y, lambda)
%COSTFUNCTIONREG Compute cost and gradient 
%for logistic regression with regularization



end