function X_rec = recoverData(Z, U, K)
%Recovers an approximation the 
%original data that has been reduced to K dimensions. It returns the
%approximate reconstruction in X_rec.


end
