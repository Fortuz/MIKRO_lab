# BME MOGI MotionLab Project

Import NatNetClient class from NatNetClient:
```python
from NatNetClient import NatNetClient
```

Instantiate NatNetClient (default values: server_ip_address="127.0.0.1", local_ip_address="127.0.0.1",
                 multicast_address="239.255.42.99", command_port=1510, data_port=1511):
```python
streamingClient = NatNetClient("192.168.1.153", "192.168.1.30")
```

Define listeners to handle received data:

```python
# This is a callback function that gets connected to the NatNet client and called once per mocap frame.
def receive_new_frame(frame_number, marker_set_count, unlabeled_markers_count, rigid_body_count,
                      skeleton_count, labeled_marker_count, time_code, time_code_sub, timestamp,
                      is_recording, tracked_models_changed):
    print("Received frame", frame_number)


# This is a callback function that gets connected to the NatNet client. It is called once per rigid body per frame
def receive_rigid_body_frame(id, position, rotation):
    print("Received frame for rigid body", id)
```

Subscribe listeners to broadcast. (default values: new_frame_listener = None, rigid_body_listener=None)

```python
streamingClient.new_frame_listener = receive_new_frame
streamingClient.rigid_body_listener = receive_rigid_body_frame
```

Start the streaming client. This will a start a command thread and a data thread for receiving motive broadcasted data.
```python
streamingClient.run()
```


For 3D visualization download: https://robodk.com/download

