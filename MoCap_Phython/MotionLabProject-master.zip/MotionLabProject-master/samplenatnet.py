from NatNetClient import NatNetClient


# This is a callback function that gets connected to the NatNet client and called once per mocap frame.
def receive_new_frame(frame_number, marker_set_count, unlabeled_markers_count, rigid_body_count,
                      skeleton_count, labeled_marker_count, time_code, time_code_sub, timestamp,
                      is_recording, tracked_models_changed):
    print("Received frame", frame_number)


# This is a callback function that gets connected to the NatNet client. It is called once per rigid body per frame
def receive_rigid_body_frame(id, position, rotation):
    print("Received frame for rigid body", id)


if __name__ == '__main__':

    # This will create a new NatNet client
    streamingClient = NatNetClient("192.168.1.153", "192.168.1.30")

    # Configure the streaming client to call our rigid body handler on the emulator to send data out.
    streamingClient.new_frame_listener = receive_new_frame
    streamingClient.rigid_body_listener = receive_rigid_body_frame

    # Start up the streaming client now that the callbacks are set up.
    # This will run perpetually, and operate on a separate thread.
    streamingClient.run()
