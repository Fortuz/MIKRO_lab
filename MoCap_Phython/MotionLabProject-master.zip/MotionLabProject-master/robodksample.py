from robolink import *    # RoboDK's API
from robodk import *      # Math toolbox for robots
import numpy as np
import time
import math
from NatNetClient import NatNetClient

# Start the RoboDK API:
RDK = Robolink()
# Get the robot item by name:
robot = RDK.Item('UR3', ITEM_TYPE_ROBOT)
# robot = RDK.ItemUserPick('Select a robot', ITEM_TYPE_ROBOT) .... kiválaztó felület minden vacakkal

joints = []

# This is a callback function that gets connected to the NatNet client and called once per mocap frame.
def receive_new_frame(frame_number, marker_set_count, unlabeled_markers_count, rigid_body_count,
                                skeleton_count, labeled_marker_count, time_code, time_code_sub, timestamp,
                                is_recording, tracked_models_changed):
    print("Received frame", frame_number)


# This is a callback function that gets connected to the NatNet client. It is called once per rigid body per frame
def receive_rigid_body_frame(id, position, rotation):
    # print("Received frame for rigid body", id)
    # print("Received position", position)
    # print("Received rotation", rotation)
    joints = np.array([position[0], position[1], position[2], rotation[0], rotation[1], rotation[3]])
    joints = joints * 100
    print("Joints", joints)
    robot.setJoints(joints.tolist())


if __name__ == '__main__':

    # # Get the reference target by name:
    # target = RDK.Item('Target 1')
    # target_pose = target.Pose()
    # xyz_ref = target_pose.Pos()
    #
    # # Move the robot to the reference point:
    # robot.MoveJ(target)

    # This will create a new NatNet client
    streamingClient = NatNetClient("192.168.1.153", "192.168.1.30")

    # Configure the streaming client to call our rigid body handler on the emulator to send data out.
    # streamingClient.new_frame_listener = receive_new_frame
    streamingClient.rigid_body_listener = receive_rigid_body_frame

    # Start up the streaming client now that the callbacks are set up.
    # This will run perpetually, and operate on a separate thread.
    streamingClient.run()